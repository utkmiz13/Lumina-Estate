# 🏢 Lumina Estate — Society Management Web App

**PRD v2.0 (16 Aug 2026) par based frontend demo** — Green Valley Residency (Lucknow) ke demo data ke saath, bilkul GitHub Pages–ready.

Ye **100% static** app hai — koi backend, koi build step, koi dependency nahi. HTML/CSS/JS files ko kisi bhi static host (GitHub Pages, Netlify, Vercel) par daalo, chal jayega. Browser mein `index.html` directly kholne par bhi kaam karta hai.

---

## 🚀 GitHub Pages Par Host Kaise Karein

### Tarika 1 — GitHub Website Se (Sabse Aasaan, No Git)

1. [github.com](https://github.com) par **New Repository** banayein (naam: `lumina-estate`)
2. Repo khulega — **"uploading an existing file"** link par click karein
3. Is folder ke **saare files/folders** drag-drop karke upload karein:
   - `index.html`, `manifest.json`, `.nojekyll`
   - `css/` folder, `js/` folder, `icons/` folder
4. **Commit changes** karein
5. Repo mein jayein → **Settings** → **Pages**
6. **Branch** mein `main` chunein, folder `/(root)` → **Save**
7. 1–2 minute mein app live ho jayega:
   `https://<aapka-username>.github.io/lumina-estate/`

### Tarika 2 — Git CLI Se

```bash
cd lumina-estate
git init
git add .
git commit -m "Lumina Estate — initial release"
git branch -M main
git remote add origin https://github.com/<username>/lumina-estate.git
git push -u origin main
# phir Settings → Pages → main branch → Save
```

> ⚠️ `.nojekyll` file zaroor rakhein — ye GitHub Pages ko Jekyll processing se rokta hai. Hash-based routing (`#/bills`) use hota hai, isliye koi extra config nahi chahiye.

---

## 🔑 Demo Accounts (1-Tap Login)

Login page par hi saare demo accounts dikhte hain — **tap karo aur andar**:

| Kaun | Role | Phone | Kya Dekhna Hai |
|---|---|---|---|
| **Col. A.K. Singh** | Society Admin (Secretary) | 9999000001 | Bill run wizard, defaulters, complaint assignment, notices, expenses, audit log |
| **Rajesh Verma** | Owner (A-304) | 9999000002 | Pending bill + late fee, UPI payment, pending visitor approval, hall booking |
| **Priya Sharma** | Tenant (B-201) | 9999000003 | Badminton booking, community complaints, polls |
| **Ramesh Kumar** | Security Guard | 9999000004 | Camera-first visitor entry, code verify, pending exits |
| **Sunita Devi** | Staff (Housekeeping) | 9999000005 | Assigned complaints — "Kaam Shuru / Ho Gaya" photo proof |
| **Ritu Verma** | Family Member (A-304) | 9999000006 | Visitor approvals + notices (no billing) |

**OTP:** Send OTP dabao — OTP screen par hi **Demo OTP** dikhta hai (autofill button bhi hai). Naya koi bhi 10-digit number daloge toh **"Pending Approval"** flow chalega — admin se approve karvao (Col. Singh login → Members → Approve).

**Account switch:** Profile menu → *Switch Account (Demo)* — ek hi browser mein Rajesh → Guard → Admin hop karke poora visitor-approval loop dekh sakte ho.

---

## ✨ Kya Bana Hai (PRD Coverage)

| Module (PRD) | Status | Demo Mein |
|---|---|---|
| 9.1 Auth, Onboarding & Profiles | ✅ P0 | OTP login, pending approval, family/vehicles, bilingual |
| 9.2 Personalized Dashboards | ✅ P0 | Har role ka alag dashboard (owner/tenant/family/admin/guard/staff) |
| 9.3 Billing Engine & Payments | ✅ P0 | Charge heads, bill run wizard, arrears, late fee, mock UPI/card/netbanking, receipts, ledger |
| 9.4 Complaint / Helpdesk | ✅ P0 | Categories, photos, SLA chips, assign, timeline, rating, reopen, community upvotes |
| 9.5 Notices & Announcements | ✅ P0 | Categories, pinning, audience targeting, read receipts + analytics, RSVP |
| 9.6 Visitor Management (VMS) | ✅ P1 | Guard camera entry, resident Allow/Deny, pre-approval codes, delivery quick-mode, daily staff, exits |
| 9.7 Facility Booking | ✅ P1 | Slots calendar, paid bookings, approval queue, conflict prevention |
| 9.8 Directory & Emergency | ✅ P1 | Committee, privacy controls, tap-to-call emergency contacts |
| 9.9 Document Repository | ✅ P1 | Folders, access levels (All/Committee/Admin), versioning |
| 9.10 Expenses & Transparency | ✅ P1 | Expense entry + void, auto income-vs-expense pie, monthly summary |
| 9.11 Polls & Voting | ✅ P2 | One-flat-one-vote, anonymous, results, deadline |
| 9.14 Emergency / SOS | ✅ P2 | Slide-to-SOS → guard/admin alert → responding status |
| Cross-cutting | ✅ | Payment flow, complaint lifecycle, committee handover note, audit log (immutable trail) |

**Isliye nahi bana (GitHub Pages = frontend-only):** real PG integration, SMS/WhatsApp delivery, server-side RBAC, multi-society backend — ye sab backend chahiye. Demo mein payment/SMS **simulated** hain (screen par clearly likha hai).

---

## 🛠️ Structure

```
lumina-estate/
├── index.html          # app shell
├── manifest.json       # PWA manifest (Add to Home Screen)
├── .nojekyll
├── css/styles.css      # design system (PRD Appendix E: Navy #1F3A5F, Gold #C98A2D)
├── icons/              # logo + PWA icons
└── js/
    ├── i18n.js         # Hindi + English (443 strings, full coverage)
    ├── seed.js         # demo data — Green Valley Residency, 28 flats
    ├── store.js        # data layer + business logic (localStorage)
    ├── ui.js           # icons, toasts, modals, formatting, camera
    ├── views-resident.js
    ├── views-admin.js
    ├── views-guard.js  # guard + staff
    └── app.js          # router, shell, auth, RBAC
```

## 💾 Data

- Saara data browser ke **localStorage** mein (`lumina:v1` key) — refresh ke baad bhi persist hota hai
- **Reset:** Profile → *Reset Demo Data*
- Payments/SMS/OTP sab **demo-simulated** — koi asli paisa ya message nahi jaata
- PRD ke DPDP spirit ke hisaab se: download-my-data, soft-delete, audit trail — sab demo mein reflect hota hai

## 📱 Tips

- Mobile browser mein kholo — bottom nav + thumb-friendly flows (guard ke liye camera-first UI)
- **Add to Home Screen** karo toh PWA icon ke saath app jaisa lagta hai
- Receipt par *Print/Save PDF* → browser ka print dialog → PDF mein save
- Language toggle har screen ke top-right par: **हिंदी / EN**

---
*PRD POC: Utkarsh · Document v2.0 · Demo build: 16 Aug 2026*
